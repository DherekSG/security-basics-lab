# TCP vs UDP

**TCP (Transmission Control Protocol):**
- Orientado à conexão
- Garante entrega dos dados
- Mais lento, porém confiável

**UDP (User Datagram Protocol):**
- Não orientado à conexão
- Não garante entrega
- Mais rápido, usado em streaming, DNS, etc.
