#!/bin/bash
echo "Atualizando pacotes..."
sudo apt update && sudo apt upgrade -y
