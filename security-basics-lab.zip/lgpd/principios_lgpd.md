# Princípios da LGPD

- Finalidade
- Adequação
- Necessidade
- Livre acesso
- Qualidade dos dados
- Transparência
- Segurança
- Prevenção
- Não discriminação
- Responsabilização e prestação de contas
