# Comandos Linux úteis para Segurança

- `netstat -tuln`: Ver portas abertas
- `ps aux`: Ver processos em execução
- `chmod`, `chown`: Permissões de arquivos
- `ufw`: Configuração de firewall
